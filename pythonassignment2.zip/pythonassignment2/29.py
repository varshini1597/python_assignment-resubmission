#29. In a given list find the total number of odd numbers, even numbers and their respetive sum and average.
list=['1','2','3','4','5','6','7','8','9','10']
even_count=0
odd_count=0
sum_even,avg_even=0,0
sum_odd,avg_odd=0,0
#size=len(list)
for i in range(len(list)):
	if(i%2==0):
		even_count=even_count+1
		sum_even+=i
	else:
		odd_count=odd_count+1
		sum_odd+=i
avg_even=sum_even/even_count
avg_odd=sum_odd/odd_count
print("odd numbers in list are",odd_count,"in number")
print("evennumbers in list are",even_count,"in number")
print("sum of even numbers in list:",sum_even,"average is:",avg_even)
print("sum of odd numbers in list:",sum_odd,"average is:",avg_odd)
