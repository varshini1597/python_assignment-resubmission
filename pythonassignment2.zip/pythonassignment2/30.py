#30. Print the pyramid pattern using .
rows=int(input("enter the number of rows:"))
#columns=int(input("enter the number of columns:"))
for row in range(0,rows):
	for j in range(0,row+1):
		print("*",end='')
		
	print("\n")
