#24. Implement a program to read alternative characters in the file. 
f=open('varsha.txt',"r")
fp=f.read()
print(fp)
for line in fp:
	for ch in line:
		print(ch)