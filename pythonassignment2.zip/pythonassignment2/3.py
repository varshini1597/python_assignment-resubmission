#3.  Implement a  program to concatenate two strings.
string1=input("enter first string")
string2=input("enter secind string")
print("concatenated string is:",string1+string2)
