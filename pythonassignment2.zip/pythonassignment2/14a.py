#14. Implement a function to implement to finc the length of the list without standard library.
list=['a','e','varsha','vikas','sujatha']
count=0
for i in list:
	count=count+1
print("Length of the list is:",count)