#9.  Implement a program to create a dictionary of students with Registration number and names. Perform the two operations, insert and delete. 
dict = {'181040012':'varshini', '181040013':'vikas', '181040014':'yuvaraj', '181040015':'pavithra'}
print("created dictionary:\n",dict)
dict['181040016']='shravani'
print("Dictionary after inserting",dict)
del dict['181040016'] # or dict.pop(181040016)
print("Dictionary after deletion",dict)
