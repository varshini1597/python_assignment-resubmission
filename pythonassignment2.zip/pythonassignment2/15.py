#15. Implement a program to print the elements of a list.
list=['a','e','varsha','vikas','sujatha','python','code']
print("list elements are:",list)