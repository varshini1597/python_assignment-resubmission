#39. Find the average number of students from records.
import csv
student_id=int(input("Enter the student registratin number\n"))
student_name=input("Enter name of student\n")
count=0
with open('student_details','a+') as csvfile:
	student_details=csv.writer(csvfile,delimiter=',',quotechar='"', quoting=csv.QUOTE_MINIMAL)
	student_details.writerow([student_id,student_name])
print("Records entered successfully")
with open('student_details','r') as csvfile:
	students_reader=csv.reader(csvfile)
	for row in students_reader:
		print(row)
		count=count+1
print("number of students are:",count)
