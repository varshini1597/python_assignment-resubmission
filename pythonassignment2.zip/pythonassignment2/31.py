#31. Implement a program to check the elements of a list is a palindrome or not.
list=['1','0','1','0','1']
#for i in range(len(list))
if list==list[::-1]:
	print("List is pallindrome")
else:
	print("List is not pallindrome") 
