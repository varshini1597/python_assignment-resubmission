#12. Implement a program with lamda functions, for finding the area of circle, triangle, square.
area_of_square=lambda a:a*a
a=int(input("enter sides of square:"))
print("area of square is:",area_of_square(a))
area_of_triangle=lambda b,h:0.5*b*h
b=int(input("enter the base of triangle:"))
h=int(input("enter the height of triangle:"))
print("area of trangle is:",area_of_triangle(b,h))
area_of_circle=lambda r:3.142*r*r
r=int(input("enter the radius of circle:"))
print("area of circle is:",area_of_circle(r))