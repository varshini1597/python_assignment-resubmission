#22. Implement a program to read a line in a file and print.
f=open('varsha.txt',"r")
fp=f.readline()
print(fp)