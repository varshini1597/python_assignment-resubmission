#14. Implement function to find the string length without using standard library.
string=input("enter the string to find length:")
count=0
for i in string:
	count=count+1
print("length of the string is:",count)