#6.  Create a list with 5 branches in SOIS. Try to do the following operations a) append b) insert c) sort d) reverse sort 
mylist=['EWT','VLSI','ESD','VIR','BIGDATA']
mylist.append('AES')#since append takes only one arguement,square braces are used
print("list after appending is\n",mylist);
mylist.insert(1,'ESI')
print("list after inserting is \n",mylist)
mylist.sort()
print("sorted list is \n",mylist)
mylist.reverse()
print("reverse of list is \n",mylist)


