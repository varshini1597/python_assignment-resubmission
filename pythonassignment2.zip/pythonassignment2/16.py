#16. Implement a program to get three values from CLA and print the sum of them.
import sys
try:
a=int(sys.argv[1])
b=int(sys.argv[2])
c=int(sys.argv[3])
sum=a+b+c
print("sum of three numbers is:",sum)
except: