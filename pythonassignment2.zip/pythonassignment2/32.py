#32. Implement a program to check the total number of students. (create a sample file with RegNo, StudentName, Branch)

import csv
import sys
count=0
f=open("32.csv",'r')
line=csv.reader(f)
for row in line:
	count=count+1
	print(row)
print("total number of students are:",count)