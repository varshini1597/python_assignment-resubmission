#23. Implement a program to write a line from the console to a file.
import sys
f=open('varsha2.txt',"a+")
args=sys.argv[1]
args1=sys.argv[2]
f.write(args)
f.write(args1)

print(args,args1)
