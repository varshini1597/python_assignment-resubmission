#26. Implement a program to convert the input string to upper case (without using standard library)
str=input("enter the string in lower case\n")
result=''
for char in str:
	#print(ch)
	result += chr(ord(char) - 32)
print("string in uppercase:",result)