#27. Implement a progam to convert the input string to lower case ( without using standard library)
str=input("enter the string in uppercase letter\n")
result=''
for char in str:
	#print(ch)
	result += chr(ord(char) + 32)
print("string in lowercase:",result)