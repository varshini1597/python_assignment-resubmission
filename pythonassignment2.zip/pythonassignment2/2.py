#2.  Implement a  program  for finding a square of a number. (without using standard api)
def square(a):
	return a*a;

number=int(input("enter the number for its square"))
print("square of a number is",square(number))